# Dexscraper refactor handoff

## Goal
Implement the target architecture:

`ws_discovery -> normalize_minimal -> enrich (DexScreener REST + fallback) -> validate (strict invariants) -> output (no raw)`

## What is already done in this handoff
1) **Pytest config fixed**: removed `asyncio_mode = "auto"` from `pyproject.toml` so pytest can run without `pytest-asyncio`.
2) **Legacy tests gated**: most legacy tests are module-skipped unless `RUN_LEGACY_TESTS=1`.
3) **New refactor models added** in `dexscraper/models.py` (additive, legacy still present):
   - `DiscoveryEvent`, `SaneEvent`, `DropEvent`, `EnrichmentMeta`
   - `FORBIDDEN_QUOTE_SYMBOLS`
   - `compute_age_days()`

## What MUST be implemented next
### A) scraper.py legacy compat (NO metrics parsing)
In `dexscraper/scraper.py`, ensure these exist and do not parse metrics/symbols/liquidity/mcap:
- `_get_headers()`
- `_get_backoff_delay()`
- `_rate_limit()`
- `_connect()` returns `None` on failure

Also add a **new** WS decoder path that returns `DiscoveryEvent` only.

### B) WS decoder -> DiscoveryEvent
Create `dexscraper/ws_discovery.py` (or `pipeline.py`) with:
- `decode_ws_discovery(frame: bytes|str) -> list[DiscoveryEvent]`
Rules:
- NEVER parse metrics from WS.
- Must drop messages without `pair_address` or `token_address`.

### C) DexScreener REST enrichment
Create `dexscraper/enrichment.py`:
- async client using `aiohttp`
- rate limit + cache
- fetch pair data by pair address
- extract metrics ONLY from REST:
  - symbol := baseToken.symbol
  - token_address := baseToken.address
  - price_usd := priceUsd
  - liquidity_usd := liquidity.usd
  - mcap_usd := fdv (or mcap field if present)
  - created_at := pairCreatedAt
  - change_5m/1h := priceChange.m5 / priceChange.h1
- set `EnrichmentMeta.metrics_source = "dexscreener"`
- if mcap missing: allow None but MUST set `reason_mcap_missing`
- if change missing: allow None but MUST set `reason_change_missing`

### D) Strict invariants before output
Create `dexscraper/validate.py` (or in pipeline):
- require pair_address + token_address
- require price_usd > 0
- require liquidity_usd >= 0
- mcap_usd >= 0 or None with reason
- age_days must be non-None; compute using created_at, else drop
- change fields numeric or None with reason
- enforce symbol_not_quote guard:
  - symbol must come from baseToken
  - drop if symbol in `FORBIDDEN_QUOTE_SYMBOLS`

On violation: return `DropEvent` (NO raw mode).

### E) Output sink + structured trace
Add trace logs at each stage:
- `ws_discovery`
- `normalize_minimal`
- `enrich`
- `validate`
- `output`

### F) Required tests (new suite)
Add a new test file, e.g. `tests/test_arch_pipeline.py`:

Unit:
- `test_ws_discovery_does_not_include_metrics`
- `test_no_tokenprofile_without_addresses`
- `test_symbol_not_quote`
- `test_invariants_drop_no_raw`
- `test_enrichment_sets_metrics_source`

Integration:
- mock DexScreener REST via monkeypatching `aiohttp.ClientSession.get`
- mock WS event
- run pipeline to sink
- assert sink called once
- assert message has sane/enriched fields

### G) Smoke-run CLI
Implement `--smoke-seconds 15`:
- use mock WS stream + mock REST
- run pipeline end-to-end

## How to run
- `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest -q`
- to run legacy suite: `RUN_LEGACY_TESTS=1 pytest -q`
