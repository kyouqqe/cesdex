"""Enrichment modules (DexScreener API, fallbacks, validation)."""
