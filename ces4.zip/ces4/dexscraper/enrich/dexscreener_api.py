from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional

import aiohttp

from dexscraper.models import TokenProfile

logger = logging.getLogger(__name__)


def _to_float(value: Any) -> Optional[float]:
    """Best-effort float conversion."""
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _parse_created_at(value: Any) -> Optional[int]:
    """Return epoch seconds from ms/sec values."""
    if value is None:
        return None
    try:
        ts = int(value)
    except (TypeError, ValueError):
        return None
    # DexScreener uses ms in many endpoints
    if ts > 10_000_000_000:
        ts = ts // 1000
    return ts


@dataclass
class DexScreenerAPIConfig:
    base_url: str = "https://api.dexscreener.com"
    timeout_s: float = 10.0
    max_retries: int = 3
    backoff_base_s: float = 0.5
    rate_limit_rps: float = 8.0
    concurrency: int = 20
    cache_ttl_s: int = 60
    # Avoid refetching the same token too frequently even if cache is bypassed.
    dedup_window_s: int = 10


class DexScreenerAPI:
    """Lightweight async client for DexScreener public API.

    We use this as the **authoritative** enrichment layer to guarantee sane
    values (price_usd, liquidity_usd, mcap/fdv, age, change m5/h1). The WebSocket
    binary extraction is treated as a discovery layer only.
    """

    def __init__(self, config: Optional[DexScreenerAPIConfig] = None) -> None:
        self._cfg = config or DexScreenerAPIConfig()
        self._sem = asyncio.Semaphore(self._cfg.concurrency)
        self._min_interval = 1.0 / max(self._cfg.rate_limit_rps, 0.1)
        self._last_req = 0.0
        # token_address -> (expires_at, TokenProfile|None)
        self._cache: Dict[str, tuple[float, Optional[TokenProfile]]] = {}
        self._inflight_until: Dict[str, float] = {}

    async def _rate_limit(self) -> None:
        now = time.time()
        delta = now - self._last_req
        if delta < self._min_interval:
            await asyncio.sleep(self._min_interval - delta)
        self._last_req = time.time()

    async def enrich_token(self, session: aiohttp.ClientSession, token: TokenProfile) -> TokenProfile:
        """In-place enrich token with API metrics. Returns the same object.

        Supported identity inputs:
        - (chain, pair_address) -> /pairs/{chain}/{pair}
        - (token_address) -> /tokens/{token_address} with best-pair selection
        """

        if token.chain and token.pair_address:
            await self._enrich_by_pair(session, token)
            return token

        if token.token_address:
            enriched = await self.enrich_address_to_profile(session, token.token_address)
            if enriched is not None:
                # copy fields into the provided token for compatibility
                token.__dict__.update(enriched.__dict__)
            return token

        return token

    async def _enrich_by_pair(self, session: aiohttp.ClientSession, token: TokenProfile) -> None:
        chain = str(token.chain).lower()
        pair = str(token.pair_address)
        url = f"{self._cfg.base_url}/latest/dex/pairs/{chain}/{pair}"

        for attempt in range(1, self._cfg.max_retries + 1):
            try:
                async with self._sem:
                    await self._rate_limit()
                    timeout = aiohttp.ClientTimeout(total=self._cfg.timeout_s)
                    async with session.get(url, timeout=timeout) as resp:
                        if resp.status >= 500:
                            raise RuntimeError(f"dexscreener_http_{resp.status}")
                        if resp.status == 429:
                            raise RuntimeError("dexscreener_rate_limited")
                        data = await resp.json()
                self._apply_pair_payload(token, data)
                token.metrics_source = "dexscreener"
                return
            except Exception as exc:
                if attempt >= self._cfg.max_retries:
                    logger.debug("[enrich] failed chain=%s pair=%s err=%r", chain, pair, exc)
                    return
                delay = self._cfg.backoff_base_s * (2 ** (attempt - 1))
                await asyncio.sleep(delay)

    def _cache_get(self, key: str) -> Optional[Optional[TokenProfile]]:
        item = self._cache.get(key)
        if not item:
            return None
        exp, value = item
        if time.time() >= exp:
            self._cache.pop(key, None)
            return None
        return value

    def _cache_set(self, key: str, value: Optional[TokenProfile]) -> None:
        self._cache[key] = (time.time() + self._cfg.cache_ttl_s, value)

    async def enrich_address_to_profile(
        self, session: aiohttp.ClientSession, address: str
    ) -> Optional[TokenProfile]:
        """Enrich a token address using /latest/dex/tokens/{address}.

        Returns a fully populated TokenProfile (identity + metrics) or None.
        """

        addr = str(address).strip()
        if not addr:
            return None

        cached = self._cache_get(addr)
        if cached is not None:
            return cached

        # Dedup: if recently inflight, skip (let next tick use cache)
        now = time.time()
        until = self._inflight_until.get(addr)
        if until is not None and now < until:
            return None
        self._inflight_until[addr] = now + self._cfg.dedup_window_s

        url = f"{self._cfg.base_url}/latest/dex/tokens/{addr}"
        timeout = aiohttp.ClientTimeout(total=self._cfg.timeout_s)

        for attempt in range(1, self._cfg.max_retries + 1):
            try:
                async with self._sem:
                    await self._rate_limit()
                    async with session.get(url, timeout=timeout) as resp:
                        if resp.status >= 500:
                            raise RuntimeError(f"dexscreener_http_{resp.status}")
                        if resp.status == 429:
                            raise RuntimeError("dexscreener_rate_limited")
                        data = await resp.json()

                pair = self._select_best_pair(addr, data)
                if pair is None:
                    self._cache_set(addr, None)
                    return None

                profile = self._pair_to_profile(addr, pair)
                self._cache_set(addr, profile)
                return profile
            except Exception as exc:
                if attempt >= self._cfg.max_retries:
                    logger.debug("[enrich] token failed addr=%s err=%r", addr, exc)
                    self._cache_set(addr, None)
                    return None
                delay = self._cfg.backoff_base_s * (2 ** (attempt - 1))
                await asyncio.sleep(delay)
        self._cache_set(addr, None)
        return None

    def _classify_drop_reason(self, token_address: str, payload: Dict[str, Any]) -> str:
        """Classify why enrichment failed for structured drop-logs."""
        pairs = payload.get("pairs") if isinstance(payload, dict) else None
        if not isinstance(pairs, list) or not pairs:
            return "no_pairs"

        token_addr_norm = str(token_address)

        base_matches = []
        for p in pairs:
            if not isinstance(p, dict):
                continue
            base = p.get("baseToken") or {}
            base_addr = base.get("address")
            if base_addr and str(base_addr) == token_addr_norm:
                base_matches.append(p)

        if not base_matches:
            return "base_token_mismatch"

        # Missing required fields (priceUsd / liquidity.usd)
        for p in base_matches:
            if p.get("priceUsd") is None:
                continue
            liq = p.get("liquidity")
            if not isinstance(liq, dict) or liq.get("usd") is None:
                continue
            # At least one viable pair exists -> selector should have picked it
            return "unknown"

        return "missing_fields"

    async def enrich_address_to_profile_diag(
        self, session: aiohttp.ClientSession, address: str
    ) -> tuple[Optional[TokenProfile], str]:
        """Enrich and return (profile|None, drop_reason)."""
        addr = str(address).strip()
        if not addr:
            return (None, "missing_identity")

        url = f"{self._cfg.base_url}/latest/dex/tokens/{addr}"
        timeout = aiohttp.ClientTimeout(total=self._cfg.timeout_s)

        for attempt in range(1, self._cfg.max_retries + 1):
            try:
                async with self._sem:
                    await self._rate_limit()
                    async with session.get(url, timeout=timeout) as resp:
                        if resp.status == 429:
                            # No raw-mode, but we do want diagnosis.
                            return (None, "rate_limited")
                        if resp.status >= 500:
                            raise RuntimeError(f"dexscreener_http_{resp.status}")
                        data = await resp.json()

                pair = self._select_best_pair(addr, data)
                if pair is None:
                    return (None, self._classify_drop_reason(addr, data))

                profile = self._pair_to_profile(addr, pair)
                return (profile, "ok")
            except Exception as exc:
                if attempt >= self._cfg.max_retries:
                    logger.debug("[enrich] token failed addr=%s err=%r", addr, exc)
                    return (None, "parse_error")
                delay = self._cfg.backoff_base_s * (2 ** (attempt - 1))
                await asyncio.sleep(delay)

        return (None, "parse_error")

    async def enrich_addresses_to_profiles_with_drops(
        self, session: aiohttp.ClientSession, addresses: list[str]
    ) -> tuple[list[TokenProfile], list[dict]]:
        """Bulk enrich addresses into full TokenProfiles plus structured drop diagnostics."""
        tasks = [self.enrich_address_to_profile_diag(session, a) for a in addresses]
        results = await asyncio.gather(*tasks)

        profiles: list[TokenProfile] = []
        drops: list[dict] = []
        for addr, (profile, reason) in zip(addresses, results):
            if isinstance(profile, TokenProfile):
                profiles.append(profile)
            else:
                drops.append(
                    {
                        "address": str(addr),
                        "drop_reason": reason,
                        "ts": int(time.time()),
                    }
                )
        return profiles, drops



    def _select_best_pair(self, token_address: str, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        pairs = payload.get("pairs") if isinstance(payload, dict) else None
        if not isinstance(pairs, list) or not pairs:
            return None

        token_addr_norm = str(token_address)

        def is_stable_quote(p: Dict[str, Any]) -> bool:
            q = p.get("quoteToken") or {}
            sym = (q.get("symbol") or "").upper()
            return sym in {"USDC", "USDT", "DAI", "USD"}

        def liq_usd(p: Dict[str, Any]) -> float:
            liq = p.get("liquidity") or {}
            try:
                return float(liq.get("usd") or 0.0)
            except Exception:
                return 0.0

        def has_required(p: Dict[str, Any]) -> bool:
            # Ensure the token is baseToken (not quoteToken) to avoid quote-noise.
            base = p.get("baseToken") or {}
            base_addr = base.get("address")
            if not base_addr or str(base_addr) != token_addr_norm:
                return False
            if p.get("priceUsd") is None:
                return False
            liq = p.get("liquidity")
            if not isinstance(liq, dict) or liq.get("usd") is None:
                return False
            return True

        candidates = [p for p in pairs if isinstance(p, dict) and has_required(p)]
        if not candidates:
            return None

        # Prefer stable quote; within that choose max liquidity.
        candidates.sort(key=lambda p: (is_stable_quote(p), liq_usd(p)), reverse=True)
        return candidates[0]

    def _pair_to_profile(self, token_address: str, pair: Dict[str, Any]) -> TokenProfile:
        # Identity
        chain_id = pair.get("chainId")
        dex_id = pair.get("dexId")
        pair_address = pair.get("pairAddress")

        base = pair.get("baseToken") or {}
        symbol = base.get("symbol")

        # Metrics
        price_usd = _to_float(pair.get("priceUsd"))
        liquidity_usd = _to_float((pair.get("liquidity") or {}).get("usd"))
        market_cap = _to_float(pair.get("marketCap"))
        fdv = _to_float(pair.get("fdv"))
        mcap_or_fdv = market_cap or fdv

        created_at = _parse_created_at(pair.get("pairCreatedAt"))
        age_days = None
        if created_at is not None:
            age_days = (time.time() - created_at) / 86400

        price_change = pair.get("priceChange") or {}
        change_5m = _to_float(price_change.get("m5"))
        change_1h = _to_float(price_change.get("h1"))

        return TokenProfile(
            symbol=str(symbol) if symbol is not None else None,
            chain=str(chain_id) if chain_id is not None else None,
            protocol=str(dex_id) if dex_id is not None else None,
            pair_address=str(pair_address) if pair_address is not None else None,
            token_address=str(token_address),
            price=price_usd,
            liquidity=liquidity_usd,
            market_cap=mcap_or_fdv,
            created_at=created_at,
            age_days=age_days,
            change_5m=change_5m,
            change_1h=change_1h,
            metrics_source="dexscreener",
        )

    def _apply_pair_payload(self, token: TokenProfile, payload: Dict[str, Any]) -> None:
        pairs = payload.get("pairs") or []
        if not pairs:
            return
        # pick the first as it matches chain/pair
        pair = pairs[0]

        price_usd = _to_float(pair.get("priceUsd"))
        liquidity_usd = _to_float((pair.get("liquidity") or {}).get("usd"))
        fdv = _to_float(pair.get("fdv"))
        market_cap = _to_float(pair.get("marketCap"))
        mcap_or_fdv = market_cap or fdv

        base_token = pair.get("baseToken") or {}
        symbol = base_token.get("symbol")
        base_addr = base_token.get("address")

        created_at = _parse_created_at(pair.get("pairCreatedAt"))
        if created_at is not None:
            age_days = (time.time() - created_at) / 86400
            token.age_days = age_days
            token.created_at = created_at
            # keep human-readable age for legacy paths
            token.age = f"{age_days:.2f}d"

        price_change = pair.get("priceChange") or {}
        token.change_5m = _to_float(price_change.get("m5"))
        token.change_1h = _to_float(price_change.get("h1"))
        token.change_6h = _to_float(price_change.get("h6"))
        token.change_24h = _to_float(price_change.get("h24"))

        if symbol and not token.symbol:
            token.symbol = symbol
        if base_addr and not token.token_address:
            token.token_address = base_addr

        # authoritative metrics
        if price_usd is not None:
            token.price = price_usd
        if liquidity_usd is not None:
            token.liquidity = liquidity_usd
        if mcap_or_fdv is not None:
            token.market_cap = mcap_or_fdv

        dex_id = pair.get("dexId")
        if dex_id and not token.protocol:
            token.protocol = str(dex_id)

        chain_id = pair.get("chainId")
        if chain_id and not token.chain:
            token.chain = str(chain_id)

        token.metrics_source = "dexscreener"


    async def enrich_addresses_to_profiles(
        self, session: aiohttp.ClientSession, addresses: list[str]
    ) -> list[TokenProfile]:
        """Bulk enrich addresses into full TokenProfiles.

        Any address that fails enrichment is dropped (no raw mode).
        """
        tasks = [self.enrich_address_to_profile(session, a) for a in addresses]
        results = await asyncio.gather(*tasks)
        return [r for r in results if isinstance(r, TokenProfile)]


async def enrich_batch(
    api: DexScreenerAPI,
    tokens: list[TokenProfile],
    session: aiohttp.ClientSession,
) -> None:
    """Concurrent enrichment for a token batch."""
    await asyncio.gather(*[api.enrich_token(session, t) for t in tokens])
