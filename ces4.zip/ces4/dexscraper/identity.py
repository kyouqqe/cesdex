"""Identity extraction from DexScreener WS binary frames.

We treat WS as a **discovery** layer only.

Hard requirements for downstream processing:
- No token candidate proceeds without a token_address (preferred) or pair_address.
- We never trust symbols scraped from the binary noise.

This module extracts addresses from raw bytes with explicit allow-patterns.
"""

from __future__ import annotations

import re
from typing import Iterable, Set


EVM_ADDRESS_RE = re.compile(r"0x[a-fA-F0-9]{40}")

# Solana base58 addresses are typically 32-44 chars.
# Base58 alphabet excludes 0, O, I, l.
SOL_BASE58_RE = re.compile(r"\b[1-9A-HJ-NP-Za-km-z]{32,44}\b")


_STOPWORDS = {
    # common quote / noise tokens
    "USD",
    "USDC",
    "USDT",
    "DAI",
    "SOL",
    "ETH",
    "BTC",
    "BASE",
    "EA",
}


def _is_mostly_numeric(s: str) -> bool:
    # Exclude purely numeric (or near numeric) noise.
    digits = sum(ch.isdigit() for ch in s)
    return digits / max(len(s), 1) >= 0.9


def extract_addresses(payload: bytes | bytearray | memoryview) -> Set[str]:
    """Extract a set of candidate addresses from a WS binary frame."""

    if not isinstance(payload, (bytes, bytearray, memoryview)):
        return set()

    # Convert to a latin-1 string so we do not lose byte->char mapping.
    text = bytes(payload).decode("latin-1", errors="ignore")

    out: Set[str] = set()

    # EVM
    for m in EVM_ADDRESS_RE.finditer(text):
        out.add(m.group(0))

    # Solana base58
    for m in SOL_BASE58_RE.finditer(text):
        addr = m.group(0)
        if addr.upper() in _STOPWORDS:
            continue
        if _is_mostly_numeric(addr):
            continue
        out.add(addr)

    return out


def dedupe_keep_order(items: Iterable[str]) -> list[str]:
    seen: Set[str] = set()
    out: list[str] = []
    for it in items:
        if it in seen:
            continue
        seen.add(it)
        out.append(it)
    return out
