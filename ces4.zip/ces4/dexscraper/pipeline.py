"""Refactored pipeline: WS discovery -> REST enrichment -> strict validation -> output.

Constraints enforced by tests:
- WS is used ONLY for discovery (addresses/identity). No metrics or symbol heuristics.
- All metrics come from REST enrichment (DexScreener REST) + explicit fallback reasons.
- Raw mode is forbidden: invalid events are dropped with structured reasons.

The repository still contains legacy WS metric extraction utilities; this pipeline
is the canonical path going forward.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Any, AsyncIterator, Awaitable, Callable, Dict, Optional, Tuple

import aiohttp

from .models import (
    FORBIDDEN_QUOTE_SYMBOLS,
    DiscoveryEvent,
    DropEvent,
    EnrichmentMeta,
    SaneEvent,
    compute_age_days,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PipelineConfig:
    """Runtime knobs; keep defaults throughput-friendly."""

    dexscreener_base_url: str = "https://api.dexscreener.com"
    # Hard cap for concurrent REST calls.
    max_enrichment_concurrency: int = 20
    # Cache TTL for pair lookups.
    cache_ttl_s: int = 15
    # REST timeout.
    rest_timeout_s: float = 8.0


class TTLCache:
    def __init__(self, ttl_s: int):
        self._ttl_s = ttl_s
        self._data: Dict[str, Tuple[float, Any]] = {}

    def get(self, key: str) -> Optional[Any]:
        item = self._data.get(key)
        if not item:
            return None
        expires_at, value = item
        if time.time() >= expires_at:
            self._data.pop(key, None)
            return None
        return value

    def set(self, key: str, value: Any) -> None:
        self._data[key] = (time.time() + self._ttl_s, value)


def _log(stage: str, **fields: Any) -> None:
    # Structured log in a single line (works with stdlib logging).
    logger.info("trace stage=%s %s", stage, " ".join(f"{k}={v}" for k, v in fields.items()))


def decode_ws_discovery(payload: Any, *, ts: Optional[int] = None) -> DiscoveryEvent | DropEvent:
    """Decode a WS payload into a DiscoveryEvent.

    Accepted payload shapes (for tests and adapters):
    - dict with keys: chain, dex, pair_address, token_address
    - dict resembling DexScreener pair JSON: {chainId, dexId, pairAddress, baseToken:{address}}

    IMPORTANT: This function must NOT extract metrics or symbols.
    """

    now_ts = int(ts or time.time())

    if not isinstance(payload, dict):
        return DropEvent(reason="ws_payload_not_object", stage="ws_discovery", ts=now_ts)

    # Preferred normalized shape.
    chain = payload.get("chain") or payload.get("chainId")
    dex = payload.get("dex") or payload.get("dexId")
    pair_address = payload.get("pair_address") or payload.get("pairAddress")

    token_address = payload.get("token_address")
    if token_address is None:
        base = payload.get("baseToken") or {}
        if isinstance(base, dict):
            token_address = base.get("address")

    if not chain or not dex or not pair_address or not token_address:
        return DropEvent(
            reason="missing_addresses",
            stage="ws_discovery",
            ts=now_ts,
            chain=str(chain) if chain else None,
            dex=str(dex) if dex else None,
            pair_address=str(pair_address) if pair_address else None,
            token_address=str(token_address) if token_address else None,
        )

    return DiscoveryEvent(
        chain=str(chain),
        dex=str(dex),
        pair_address=str(pair_address),
        token_address=str(token_address),
        ts=now_ts,
        ws_topic=payload.get("ws_topic"),
    )


class DexScreenerClient:
    """Thin async client for DexScreener REST."""

    def __init__(self, session: aiohttp.ClientSession, base_url: str, timeout_s: float):
        self._session = session
        self._base_url = base_url.rstrip("/")
        self._timeout = aiohttp.ClientTimeout(total=timeout_s)

    async def get_pair(self, chain: str, pair_address: str) -> Dict[str, Any]:
        # DexScreener public endpoint: /latest/dex/pairs/{chain}/{pair}
        url = f"{self._base_url}/latest/dex/pairs/{chain}/{pair_address}"
        async with self._session.get(url, timeout=self._timeout) as resp:
            resp.raise_for_status()
            return await resp.json()


def _extract_pair_fields(pair: Dict[str, Any]) -> Tuple[Optional[str], Optional[float], Optional[float], Optional[float], Optional[int], Optional[float], Optional[float]]:
    """Extract baseToken symbol + metrics from a DexScreener pair object."""

    base = pair.get("baseToken") or {}
    symbol = base.get("symbol")

    price_usd = None
    if pair.get("priceUsd") is not None:
        try:
            price_usd = float(pair["priceUsd"])
        except Exception:
            price_usd = None

    liquidity_usd = None
    liq = pair.get("liquidity")
    if isinstance(liq, dict) and liq.get("usd") is not None:
        try:
            liquidity_usd = float(liq["usd"])
        except Exception:
            liquidity_usd = None

    # Some pairs provide marketCap, others only fdv.
    mcap_usd = None
    if pair.get("marketCap") is not None:
        try:
            mcap_usd = float(pair["marketCap"])
        except Exception:
            mcap_usd = None

    created_at = pair.get("pairCreatedAt")
    try:
        created_at_ts = int(created_at) if created_at is not None else None
    except Exception:
        created_at_ts = None

    price_change_5m = None
    price_change_1h = None
    pc = pair.get("priceChange")
    if isinstance(pc, dict):
        if pc.get("m5") is not None:
            try:
                price_change_5m = float(pc["m5"])
            except Exception:
                price_change_5m = None
        if pc.get("h1") is not None:
            try:
                price_change_1h = float(pc["h1"])
            except Exception:
                price_change_1h = None

    return symbol, price_usd, liquidity_usd, mcap_usd, created_at_ts, price_change_5m, price_change_1h


def validate_and_build(
    discovery: DiscoveryEvent,
    *,
    symbol: Optional[str],
    price_usd: Optional[float],
    liquidity_usd: Optional[float],
    mcap_usd: Optional[float],
    age_days: Optional[float],
    change_5m: Optional[float],
    change_1h: Optional[float],
    meta: EnrichmentMeta,
) -> SaneEvent | DropEvent:
    """Apply strict invariants and quote guard."""

    # Addresses are non-empty strings.
    if not discovery.pair_address or not discovery.token_address:
        return DropEvent(
            reason="missing_addresses",
            stage="validate",
            ts=discovery.ts,
            chain=discovery.chain,
            dex=discovery.dex,
            pair_address=discovery.pair_address,
            token_address=discovery.token_address,
        )

    if symbol is None or not str(symbol).strip():
        return DropEvent(
            reason="missing_symbol",
            stage="validate",
            ts=discovery.ts,
            chain=discovery.chain,
            dex=discovery.dex,
            pair_address=discovery.pair_address,
            token_address=discovery.token_address,
        )

    sym = str(symbol).strip()
    if sym.upper() in FORBIDDEN_QUOTE_SYMBOLS:
        return DropEvent(
            reason="symbol_is_quote",
            stage="validate",
            ts=discovery.ts,
            chain=discovery.chain,
            dex=discovery.dex,
            pair_address=discovery.pair_address,
            token_address=discovery.token_address,
        )

    if price_usd is None or price_usd <= 0:
        return DropEvent(
            reason="invalid_price_usd",
            stage="validate",
            ts=discovery.ts,
            chain=discovery.chain,
            dex=discovery.dex,
            pair_address=discovery.pair_address,
            token_address=discovery.token_address,
        )

    if liquidity_usd is None or liquidity_usd < 0:
        return DropEvent(
            reason="invalid_liquidity_usd",
            stage="validate",
            ts=discovery.ts,
            chain=discovery.chain,
            dex=discovery.dex,
            pair_address=discovery.pair_address,
            token_address=discovery.token_address,
        )

    if mcap_usd is not None and mcap_usd < 0:
        return DropEvent(
            reason="invalid_mcap_usd",
            stage="validate",
            ts=discovery.ts,
            chain=discovery.chain,
            dex=discovery.dex,
            pair_address=discovery.pair_address,
            token_address=discovery.token_address,
        )

    if mcap_usd is None and not meta.reason_mcap_missing:
        return DropEvent(
            reason="mcap_missing_without_reason",
            stage="validate",
            ts=discovery.ts,
            chain=discovery.chain,
            dex=discovery.dex,
            pair_address=discovery.pair_address,
            token_address=discovery.token_address,
        )

    if age_days is None:
        return DropEvent(
            reason="missing_age_days",
            stage="validate",
            ts=discovery.ts,
            chain=discovery.chain,
            dex=discovery.dex,
            pair_address=discovery.pair_address,
            token_address=discovery.token_address,
        )

    # change_5m/1h: allowed None but requires explicit reason + metrics_source.
    if (change_5m is None or change_1h is None) and not meta.reason_change_missing:
        return DropEvent(
            reason="change_missing_without_reason",
            stage="validate",
            ts=discovery.ts,
            chain=discovery.chain,
            dex=discovery.dex,
            pair_address=discovery.pair_address,
            token_address=discovery.token_address,
        )

    if not meta.metrics_source:
        return DropEvent(
            reason="missing_metrics_source",
            stage="validate",
            ts=discovery.ts,
            chain=discovery.chain,
            dex=discovery.dex,
            pair_address=discovery.pair_address,
            token_address=discovery.token_address,
        )

    return SaneEvent(
        chain=discovery.chain,
        dex=discovery.dex,
        pair_address=discovery.pair_address,
        token_address=discovery.token_address,
        symbol=sym,
        price_usd=float(price_usd),
        liquidity_usd=float(liquidity_usd),
        mcap_usd=float(mcap_usd) if mcap_usd is not None else None,
        age_days=float(age_days),
        change_5m=change_5m,
        change_1h=change_1h,
        meta=meta,
        ts=discovery.ts,
    )


def format_signal_message(ev: SaneEvent) -> str:
    """Human-readable message for sinks. No raw and no quote symbol."""

    def fmt_num(x: Optional[float]) -> str:
        if x is None:
            return "?"
        # simple grouping
        return f"{x:,.0f}" if abs(x) >= 1000 else f"{x:.6g}"

    def fmt_pct(p: Optional[float]) -> str:
        if p is None:
            return "?"
        sign = "+" if p >= 0 else ""
        return f"{sign}{p:.2f}%"

    return (
        f"{ev.symbol} | {ev.chain.upper()} | 5m {fmt_pct(ev.change_5m)} | 1h {fmt_pct(ev.change_1h)}\n\n"
        f"• Source: {ev.chain} / {ev.dex}\n"
        f"• Pair: {ev.pair_address}\n"
        f"• Price (USD): {ev.price_usd:.10g}$\n\n"
        f"• Days: {ev.age_days:.0f} days\n"
        f"• Liquidity: {fmt_num(ev.liquidity_usd)}$\n\n"
        f"MCap: {fmt_num(ev.mcap_usd) if ev.mcap_usd is not None else '?'}$\n\n"
        f"Contract:\n{ev.token_address}\n\n"
        f"Meta: source={ev.meta.metrics_source}"
    )


class DiscoveryToOutputPipeline:
    """End-to-end processing for a single discovery event."""

    def __init__(self, config: PipelineConfig):
        self._config = config
        self._sem = asyncio.Semaphore(config.max_enrichment_concurrency)
        self._cache = TTLCache(config.cache_ttl_s)

    async def process(
        self,
        discovery_payload: Any,
        *,
        session: aiohttp.ClientSession,
        output_sink: Callable[[SaneEvent, str], Awaitable[None]],
    ) -> Optional[DropEvent]:
        """Return DropEvent if dropped, else None (sent)."""

        d = decode_ws_discovery(discovery_payload)
        if isinstance(d, DropEvent):
            _log("ws_discovery", result="drop", reason=d.reason)
            return d

        _log("ws_discovery", chain=d.chain, dex=d.dex, pair=d.pair_address, token=d.token_address)

        _log("normalize_minimal", pair=d.pair_address)

        # Enrich
        async with self._sem:
            cached = self._cache.get(f"{d.chain}:{d.pair_address}")
            if cached is None:
                client = DexScreenerClient(
                    session,
                    base_url=self._config.dexscreener_base_url,
                    timeout_s=self._config.rest_timeout_s,
                )
                try:
                    data = await client.get_pair(d.chain, d.pair_address)
                except Exception as e:
                    drop = DropEvent(
                        reason=f"enrichment_http_error:{type(e).__name__}",
                        stage="enrich",
                        ts=d.ts,
                        chain=d.chain,
                        dex=d.dex,
                        pair_address=d.pair_address,
                        token_address=d.token_address,
                    )
                    _log("enrich", result="drop", reason=drop.reason, pair=d.pair_address)
                    return drop
                self._cache.set(f"{d.chain}:{d.pair_address}", data)
            else:
                data = cached

        _log("enrich", result="ok", pair=d.pair_address)

        pairs = data.get("pairs") if isinstance(data, dict) else None
        if not isinstance(pairs, list) or not pairs:
            drop = DropEvent(
                reason="enrichment_no_pairs",
                stage="enrich",
                ts=d.ts,
                chain=d.chain,
                dex=d.dex,
                pair_address=d.pair_address,
                token_address=d.token_address,
            )
            _log("enrich", result="drop", reason=drop.reason, pair=d.pair_address)
            return drop

        pair_obj = pairs[0]
        symbol, price_usd, liquidity_usd, mcap_usd, created_at_ts, change_5m, change_1h = _extract_pair_fields(pair_obj)

        # age must be sane; if missing, drop.
        age_days = compute_age_days(created_at_ts, now_ts=d.ts)

        meta = EnrichmentMeta(
            metrics_source="dexscreener",
            reason_mcap_missing=None if mcap_usd is not None else "dexscreener_missing_marketCap",
            reason_change_missing=None if (change_5m is not None and change_1h is not None) else "dexscreener_missing_priceChange",
        )

        ev_or_drop = validate_and_build(
            d,
            symbol=symbol,
            price_usd=price_usd,
            liquidity_usd=liquidity_usd,
            mcap_usd=mcap_usd,
            age_days=age_days,
            change_5m=change_5m,
            change_1h=change_1h,
            meta=meta,
        )

        if isinstance(ev_or_drop, DropEvent):
            _log("validate", result="drop", reason=ev_or_drop.reason, pair=d.pair_address)
            return ev_or_drop

        _log("validate", result="ok", pair=d.pair_address, symbol=ev_or_drop.symbol)

        msg = format_signal_message(ev_or_drop)
        await output_sink(ev_or_drop, msg)
        _log("output", result="sent", pair=d.pair_address)
        return None


async def smoke_run(
    *,
    seconds: int,
    ws_source: AsyncIterator[Any],
    rest_session: aiohttp.ClientSession,
    output_sink: Callable[[SaneEvent, str], Awaitable[None]],
    config: Optional[PipelineConfig] = None,
) -> None:
    """Consume from ws_source for up to `seconds` and push validated output."""

    cfg = config or PipelineConfig()
    pipeline = DiscoveryToOutputPipeline(cfg)

    deadline = time.time() + float(seconds)
    async for item in ws_source:
        if time.time() >= deadline:
            break
        await pipeline.process(item, session=rest_session, output_sink=output_sink)
