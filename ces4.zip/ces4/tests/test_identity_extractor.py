import asyncio

from dexscraper.identity import extract_addresses
from dexscraper.enrich.dexscreener_api import DexScreenerAPI


def test_address_extractor_filters_noise_symbols() -> None:
    payload = b"USD EA SOL USDC USDT"  # no addresses
    assert extract_addresses(payload) == set()


def test_address_extractor_finds_evm_and_solana() -> None:
    evm = b"0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
    sol = b"CrAr4RRJMBVwRsZtT62pEhfA9H5utymC2mVx8e7FreP2"
    payload = b"noise " + evm + b" more " + sol + b" end"
    out = extract_addresses(payload)
    assert "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2" in out
    assert "CrAr4RRJMBVwRsZtT62pEhfA9H5utymC2mVx8e7FreP2" in out


class _FakeResp:
    def __init__(self, payload, status: int = 200):
        self._payload = payload
        self.status = status

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def json(self):
        return self._payload


class _FakeSession:
    def __init__(self, payload):
        self._payload = payload
        self.urls = []

    def get(self, url: str, timeout=None):
        self.urls.append(url)
        return _FakeResp(self._payload)


def test_best_pair_selector_prefers_stable_and_max_liquidity() -> None:
    token = "TOKEN"
    payload = {
        "pairs": [
            {
                "chainId": "solana",
                "dexId": "orca",
                "pairAddress": "P1",
                "baseToken": {"address": token, "symbol": "AAA"},
                "quoteToken": {"symbol": "SOL"},
                "priceUsd": "1.0",
                "liquidity": {"usd": 999999},
                "marketCap": 100,
                "pairCreatedAt": 1_600_000_000,
                "priceChange": {"m5": 1.0, "h1": 2.0},
            },
            {
                "chainId": "solana",
                "dexId": "raydium",
                "pairAddress": "P2",
                "baseToken": {"address": token, "symbol": "AAA"},
                "quoteToken": {"symbol": "USDC"},
                "priceUsd": "1.0",
                "liquidity": {"usd": 1000},
                "marketCap": 100,
                "pairCreatedAt": 1_600_000_000,
                "priceChange": {"m5": 1.0, "h1": 2.0},
            },
        ]
    }

    api = DexScreenerAPI()
    chosen = api._select_best_pair(token, payload)  # type: ignore[attr-defined]
    assert chosen is not None
    # Stable quote (USDC) wins over non-stable SOL even with lower liquidity.
    assert chosen["pairAddress"] == "P2"


def test_integration_address_to_profile_mock() -> None:
    token = "TOKEN"
    payload = {
        "pairs": [
            {
                "chainId": "ethereum",
                "dexId": "uniswap_v2",
                "pairAddress": "PAIR",
                "baseToken": {"address": token, "symbol": "WETH"},
                "quoteToken": {"symbol": "USDC"},
                "priceUsd": "3000.0",
                "liquidity": {"usd": 2000000},
                "fdv": 123,
                "pairCreatedAt": 1_600_000_000,
                "priceChange": {"m5": -0.5, "h1": 0.1},
            }
        ]
    }

    api = DexScreenerAPI()
    session = _FakeSession(payload)

    async def _run():
        prof = await api.enrich_address_to_profile(session, token)  # type: ignore[arg-type]
        assert prof is not None
        assert prof.chain == "ethereum"
        assert prof.protocol == "uniswap_v2"
        assert prof.pair_address == "PAIR"
        assert prof.token_address == token
        assert prof.symbol == "WETH"
        assert prof.price == 3000.0
        assert prof.liquidity == 2000000.0
        assert prof.market_cap == 123.0
        assert prof.age_days is not None
        assert prof.metrics_source == "dexscreener"

    asyncio.run(_run())
