#!/usr/bin/env python3
"""Refactor tests for dexscraper pipeline.

WS is discovery-only. Metrics are enrichment-only. Raw mode forbidden.

NOTE: PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 is required by the project, so tests
must not depend on pytest-asyncio. We use asyncio.run().
"""

import asyncio
from typing import Any, Dict, List, Optional

import pytest

from dexscraper.pipeline import DiscoveryToOutputPipeline, PipelineConfig, decode_ws_discovery
from dexscraper.models import DropEvent, FORBIDDEN_QUOTE_SYMBOLS


def run(coro):
    return asyncio.run(coro)


class FakeResponse:
    def __init__(self, payload: Dict[str, Any], status: int = 200):
        self._payload = payload
        self.status = status

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    def raise_for_status(self):
        if self.status >= 400:
            raise RuntimeError(f"http {self.status}")

    async def json(self):
        return self._payload


class FakeSession:
    def __init__(self, payload: Dict[str, Any]):
        self._payload = payload
        self.requested_urls: List[str] = []

    def get(self, url: str, timeout=None):
        self.requested_urls.append(url)
        return FakeResponse(self._payload)


def make_pair_json(
    *,
    symbol: str,
    price_usd: str = "1.23",
    liquidity_usd: float = 1000.0,
    market_cap: Optional[float] = 123456.0,
    pair_created_at: int = 1_600_000_000,
    change_m5: Optional[float] = 1.0,
    change_h1: Optional[float] = 2.0,
):
    pair: Dict[str, Any] = {
        "chainId": "solana",
        "dexId": "raydium",
        "pairAddress": "PAIR",
        "baseToken": {"address": "TOKEN", "symbol": symbol},
        "priceUsd": price_usd,
        "liquidity": {"usd": liquidity_usd},
        "pairCreatedAt": pair_created_at,
        "priceChange": {"m5": change_m5, "h1": change_h1},
    }
    if market_cap is not None:
        pair["marketCap"] = market_cap
    return {"pairs": [pair]}


def test_ws_discovery_does_not_include_metrics():
    payload = {
        "chainId": "solana",
        "dexId": "raydium",
        "pairAddress": "PAIR",
        "baseToken": {"address": "TOKEN", "symbol": "SHOULD_NOT_BE_USED"},
        "priceUsd": "999",  # forbidden to use
        "liquidity": {"usd": 999999},  # forbidden to use
    }
    ev = decode_ws_discovery(payload)
    assert not isinstance(ev, DropEvent)
    # DiscoveryEvent has only identity fields
    assert not hasattr(ev, "price_usd")
    assert not hasattr(ev, "liquidity_usd")
    assert not hasattr(ev, "symbol")


def test_no_tokenprofile_without_addresses():
    payload = {"chainId": "solana", "dexId": "raydium"}
    ev = decode_ws_discovery(payload)
    assert isinstance(ev, DropEvent)
    assert ev.reason == "missing_addresses"
    assert ev.stage == "ws_discovery"


def test_symbol_not_quote():
    # If enrichment returns quote symbol as baseToken.symbol, it must drop.
    forbidden = next(iter(FORBIDDEN_QUOTE_SYMBOLS))
    fake_json = make_pair_json(symbol=forbidden)
    session = FakeSession(fake_json)

    pipeline = DiscoveryToOutputPipeline(PipelineConfig())

    sent: List[str] = []

    async def sink(ev, msg):
        sent.append(msg)

    drop = run(
        pipeline.process(
            {"chainId": "solana", "dexId": "raydium", "pairAddress": "PAIR", "baseToken": {"address": "TOKEN"}},
            session=session,  # type: ignore[arg-type]
            output_sink=sink,
        )
    )

    assert sent == []
    assert drop is not None
    assert drop.reason == "symbol_is_quote"


def test_invariants_drop_no_raw():
    # priceUsd <= 0 must drop; and nothing is emitted.
    fake_json = make_pair_json(symbol="ABC", price_usd="0")
    session = FakeSession(fake_json)
    pipeline = DiscoveryToOutputPipeline(PipelineConfig())

    called = 0

    async def sink(ev, msg):
        nonlocal called
        called += 1

    drop = run(
        pipeline.process(
            {"chainId": "solana", "dexId": "raydium", "pairAddress": "PAIR", "baseToken": {"address": "TOKEN"}},
            session=session,  # type: ignore[arg-type]
            output_sink=sink,
        )
    )

    assert called == 0
    assert drop is not None
    assert drop.stage == "validate"
    assert drop.reason == "invalid_price_usd"


def test_enrichment_sets_metrics_source():
    fake_json = make_pair_json(symbol="ABC")
    session = FakeSession(fake_json)
    pipeline = DiscoveryToOutputPipeline(PipelineConfig())

    got_meta = {}

    async def sink(ev, msg):
        got_meta["metrics_source"] = ev.meta.metrics_source

    drop = run(
        pipeline.process(
            {"chainId": "solana", "dexId": "raydium", "pairAddress": "PAIR", "baseToken": {"address": "TOKEN"}},
            session=session,  # type: ignore[arg-type]
            output_sink=sink,
        )
    )

    assert drop is None
    assert got_meta["metrics_source"] == "dexscreener"


def test_integration_mock_ws_and_rest_to_output():
    fake_json = make_pair_json(symbol="MON", liquidity_usd=559_992, market_cap=3_035_093)
    session = FakeSession(fake_json)
    pipeline = DiscoveryToOutputPipeline(PipelineConfig())

    messages: List[str] = []

    async def sink(ev, msg):
        messages.append(msg)

    drop = run(
        pipeline.process(
            {
                "chainId": "solana",
                "dexId": "jupiter",
                "pairAddress": "Czfq3xZZ...fu44zE",
                "baseToken": {"address": "CrAr4RRJMBVwRsZtT62pEhfA9H5utymC2mVx8e7FreP2"},
            },
            session=session,  # type: ignore[arg-type]
            output_sink=sink,
        )
    )

    assert drop is None
    assert len(messages) == 1
    msg = messages[0]
    # sanity: contains enriched fields
    assert "MON | SOLANA" in msg
    assert "Liquidity" in msg
    assert "MCap" in msg
    assert "Contract" in msg
    # forbidden: no quote symbol should appear as the event symbol header
    assert not msg.startswith("USDC |")
    assert not msg.startswith("SOL |")
