import asyncio
import logging
from typing import Any, AsyncIterator, Dict, List

from dexscraper.pipeline import PipelineConfig, smoke_run


def run(coro):
    return asyncio.run(coro)


class FakeResponse:
    def __init__(self, payload: Dict[str, Any]):
        self._payload = payload
        self.status = 200

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    def raise_for_status(self):
        return None

    async def json(self):
        return self._payload


class FakeSession:
    def __init__(self, payload: Dict[str, Any]):
        self._payload = payload

    def get(self, url: str, timeout=None):
        return FakeResponse(self._payload)


async def _ws_source_once(item: Any) -> AsyncIterator[Any]:
    yield item


def test_smoke_run_with_mock_ws_and_rest(caplog):
    caplog.set_level(logging.INFO)

    fake_json = {
        "pairs": [
            {
                "chainId": "solana",
                "dexId": "jupiter",
                "pairAddress": "PAIR",
                "baseToken": {"address": "TOKEN", "symbol": "SOLX"},
                "priceUsd": "84",
                "liquidity": {"usd": 10461075249},
                "marketCap": 72028513261,
                "pairCreatedAt": 1_600_000_000,
                "priceChange": {"m5": -5.62, "h1": -5.62},
            }
        ]
    }

    session = FakeSession(fake_json)
    messages: List[str] = []

    async def sink(ev, msg):
        messages.append(msg)

    run(
        smoke_run(
            seconds=15,
            ws_source=_ws_source_once(
                {
                    "chainId": "solana",
                    "dexId": "jupiter",
                    "pairAddress": "PAIR",
                    "baseToken": {"address": "TOKEN"},
                }
            ),
            rest_session=session,  # type: ignore[arg-type]
            output_sink=sink,
            config=PipelineConfig(cache_ttl_s=0),
        )
    )

    assert len(messages) == 1
    # trace should show all stages
    text = "\n".join(r.message for r in caplog.records)
    assert "stage=ws_discovery" in text
    assert "stage=normalize_minimal" in text
    assert "stage=enrich" in text
    assert "stage=validate" in text
    assert "stage=output" in text
